import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/api',
    component: ComponentCreator('/api', '24b'),
    exact: true
  },
  {
    path: '/blog',
    component: ComponentCreator('/blog', 'b2f'),
    exact: true
  },
  {
    path: '/blog/archive',
    component: ComponentCreator('/blog/archive', '182'),
    exact: true
  },
  {
    path: '/blog/authors',
    component: ComponentCreator('/blog/authors', '0b7'),
    exact: true
  },
  {
    path: '/blog/authors/all-sebastien-lorber-articles',
    component: ComponentCreator('/blog/authors/all-sebastien-lorber-articles', '4a1'),
    exact: true
  },
  {
    path: '/blog/authors/yangshun',
    component: ComponentCreator('/blog/authors/yangshun', 'a68'),
    exact: true
  },
  {
    path: '/blog/first-blog-post',
    component: ComponentCreator('/blog/first-blog-post', '89a'),
    exact: true
  },
  {
    path: '/blog/long-blog-post',
    component: ComponentCreator('/blog/long-blog-post', '9ad'),
    exact: true
  },
  {
    path: '/blog/mdx-blog-post',
    component: ComponentCreator('/blog/mdx-blog-post', 'e9f'),
    exact: true
  },
  {
    path: '/blog/tags',
    component: ComponentCreator('/blog/tags', '287'),
    exact: true
  },
  {
    path: '/blog/tags/docusaurus',
    component: ComponentCreator('/blog/tags/docusaurus', '704'),
    exact: true
  },
  {
    path: '/blog/tags/facebook',
    component: ComponentCreator('/blog/tags/facebook', '858'),
    exact: true
  },
  {
    path: '/blog/tags/hello',
    component: ComponentCreator('/blog/tags/hello', '299'),
    exact: true
  },
  {
    path: '/blog/tags/hola',
    component: ComponentCreator('/blog/tags/hola', '00d'),
    exact: true
  },
  {
    path: '/blog/welcome',
    component: ComponentCreator('/blog/welcome', 'd2b'),
    exact: true
  },
  {
    path: '/features',
    component: ComponentCreator('/features', '13a'),
    exact: true
  },
  {
    path: '/markdown-page',
    component: ComponentCreator('/markdown-page', '3d7'),
    exact: true
  },
  {
    path: '/docs',
    component: ComponentCreator('/docs', 'c8c'),
    routes: [
      {
        path: '/docs',
        component: ComponentCreator('/docs', '570'),
        routes: [
          {
            path: '/docs',
            component: ComponentCreator('/docs', '5b5'),
            routes: [
              {
                path: '/docs/api/introduction',
                component: ComponentCreator('/docs/api/introduction', '38e'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/api/libraries',
                component: ComponentCreator('/docs/api/libraries', '7fe'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/api/nodes',
                component: ComponentCreator('/docs/api/nodes', 'b9e'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/api/servers',
                component: ComponentCreator('/docs/api/servers', 'b09'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/api/services',
                component: ComponentCreator('/docs/api/services', '1d2'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/api/users',
                component: ComponentCreator('/docs/api/users', '31c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/content-editing-guide',
                component: ComponentCreator('/docs/content-editing-guide', 'daf'),
                exact: true
              },
              {
                path: '/docs/content-strategy',
                component: ComponentCreator('/docs/content-strategy', 'e2a'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/intro',
                component: ComponentCreator('/docs/intro', '61d'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/migration',
                component: ComponentCreator('/docs/migration', 'e31'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/performance-optimization',
                component: ComponentCreator('/docs/performance-optimization', 'f13'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/panel/centos',
                component: ComponentCreator('/docs/project/panel/centos', 'bee'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/panel/configuration',
                component: ComponentCreator('/docs/project/panel/configuration', '620'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/panel/debian',
                component: ComponentCreator('/docs/project/panel/debian', '402'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/panel/installation',
                component: ComponentCreator('/docs/project/panel/installation', 'b69'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/panel/ubuntu',
                component: ComponentCreator('/docs/project/panel/ubuntu', '9ec'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/servers/creation',
                component: ComponentCreator('/docs/project/servers/creation', '585'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/troubleshooting',
                component: ComponentCreator('/docs/project/troubleshooting', 'dcb'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/wings/centos',
                component: ComponentCreator('/docs/project/wings/centos', '27f'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/wings/debian',
                component: ComponentCreator('/docs/project/wings/debian', '414'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/wings/installing',
                component: ComponentCreator('/docs/project/wings/installing', '81a'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/project/wings/ubuntu',
                component: ComponentCreator('/docs/project/wings/ubuntu', '00e'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/security',
                component: ComponentCreator('/docs/security', '3ef'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/servers/backups',
                component: ComponentCreator('/docs/servers/backups', '053'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/servers/mods',
                component: ComponentCreator('/docs/servers/mods', 'f6f'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/servers/monitoring',
                component: ComponentCreator('/docs/servers/monitoring', '4fd'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/servers/setup',
                component: ComponentCreator('/docs/servers/setup', '38b'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/troubleshooting',
                component: ComponentCreator('/docs/troubleshooting', 'e02'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/update-guide',
                component: ComponentCreator('/docs/update-guide', '1d5'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/users',
                component: ComponentCreator('/docs/users', 'a10'),
                exact: true,
                sidebar: "tutorialSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/',
    component: ComponentCreator('/', '2e1'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
