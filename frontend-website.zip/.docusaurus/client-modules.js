export default [
  require("C:\\Users\\sneaky\\Documents\\GitHub\\frontend-website\\node_modules\\infima\\dist\\css\\default\\default.css"),
  require("C:\\Users\\sneaky\\Documents\\GitHub\\frontend-website\\node_modules\\@docusaurus\\theme-classic\\lib\\prism-include-languages"),
  require("C:\\Users\\sneaky\\Documents\\GitHub\\frontend-website\\node_modules\\@docusaurus\\theme-classic\\lib\\nprogress"),
  require("C:\\Users\\sneaky\\Documents\\GitHub\\frontend-website\\src\\css\\custom.css"),
];
