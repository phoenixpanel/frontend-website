---
sidebar_position: 2
---

# Wings on Ubuntu

This guide will walk you through the process of installing PhoenixPanel Wings on Ubuntu.

## Supported Versions

PhoenixPanel Wings officially supports:
- Ubuntu 20.04 LTS (Focal Fossa)
- Ubuntu 22.04 LTS (Jammy Jellyfish)

## System Requirements

| Type | Minimum | Recommended |
|------|---------|------------|
| CPU  | 2 cores | 4+ cores   |
| RAM  | 4GB     | 8GB+       |
| Disk | 30GB    | 50GB+      |
| Network | 100Mbps | 1Gbps+   |

:::caution
Wings requires virtualization to be enabled on your system. This is usually enabled in your BIOS/UEFI settings.
:::

## Installation Steps

### Step 1: Update System Packages

First, make sure your system is up to date:

```bash
sudo apt update
sudo apt upgrade -y
```

### Step 2: Install Docker

Docker is required for Wings to run game servers in containers:

```bash
# Add Docker's official GPG key
sudo apt install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

# Add the Docker repository
echo \
  "deb [arch="$(dpkg --print-architecture)" signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  "$(. /etc/os-release && echo "$VERSION_CODENAME")" stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
  
# Update apt and install Docker
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

### Step 3: Install Additional Dependencies

```bash
sudo apt install -y tar unzip curl
```

### Step 4: Start and Enable Docker

```bash
sudo systemctl enable --now docker
```

### Step 5: Add Current User to Docker Group

This allows your user to run Docker commands without sudo:

```bash
sudo usermod -aG docker $USER
```

:::caution
After running the command above, you need to log out and back in for the group changes to take effect.
:::

### Step 6: Download Wings

```bash
sudo mkdir -p /etc/phoenixpanel /var/lib/phoenixpanel
sudo curl -L -o /usr/local/bin/wings "https://github.com/phoenixpanel/wings/releases/latest/download/wings_linux_amd64"
sudo chmod u+x /usr/local/bin/wings
```

### Step 7: Configure Wings

Get the Wings configuration from your PhoenixPanel admin area. In the admin panel:

1. Navigate to **Nodes** > **Add New**
2. Fill in the node details and save
3. Click on the node you just created
4. Click on the **Configuration** tab
5. Copy the configuration

Then, create the configuration file on your Wings server:

```bash
sudo nano /etc/phoenixpanel/config.yml
```

Paste the configuration you copied from the panel. It should look similar to this:

```yaml
debug: false
uuid: d0597e88-2c8a-4663-8b1a-7a2255be5fdf
token_id: 1
token: RdmrbT...
api:
  host: 0.0.0.0
  port: 8080
  ssl:
    enabled: false
    cert: 
    key: 
  upload_limit: 100
system:
  data: /var/lib/phoenixpanel
  sftp:
    bind_port: 2022
    bind_addr: 0.0.0.0
allowed_mounts: []
remote: https://your.panel.com
```

### Step 8: Create systemd Service

Create a systemd service file to manage the Wings daemon:

```bash
sudo curl -L -o /etc/systemd/system/wings.service "https://raw.githubusercontent.com/phoenixpanel/wings/main/install/wings.service"
```

### Step 9: Start and Enable Wings

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now wings
```

### Step 10: Configure Firewall

If you're using UFW (Ubuntu's default firewall), allow the required ports:

```bash
sudo apt install -y ufw
sudo ufw allow 22/tcp
sudo ufw allow 8080/tcp
sudo ufw allow 2022/tcp

# Allow game server ports (example range - adjust as needed)
sudo ufw allow 25000:35000/tcp
sudo ufw allow 25000:35000/udp

# Enable UFW if it's not already enabled
sudo ufw enable
```

## Verifying the Installation

Check if Wings is running correctly:

```bash
sudo systemctl status wings
```

You should see output indicating that the service is active.

To view the Wings logs:

```bash
sudo journalctl -u wings --no-pager -n 50
```

## Ubuntu-Specific Optimization

### Increasing Open File Limits

Game servers often need to open many files simultaneously. Increase the limits:

```bash
sudo nano /etc/security/limits.conf
```

Add the following lines:

```
*               soft    nofile          1048576
*               hard    nofile          1048576
root            soft    nofile          1048576
root            hard    nofile          1048576
```

### Disable Swapping

For better performance, you may want to disable swapping:

```bash
sudo sysctl -w vm.swappiness=0
```

To make this change permanent:

```bash
echo 'vm.swappiness=0' | sudo tee -a /etc/sysctl.conf
```

### Network Tuning

Adjust network settings for better performance:

```bash
echo 'net.core.somaxconn=65535' | sudo tee -a /etc/sysctl.conf
echo 'net.ipv4.tcp_max_syn_backlog=65535' | sudo tee -a /etc/sysctl.conf
echo 'net.ipv4.tcp_syncookies=1' | sudo tee -a /etc/sysctl.conf
sudo sysctl -p
```

## Troubleshooting

### Docker Permission Issues

If you see "permission denied" errors when running Docker commands:

```bash
# Make sure you added your user to the Docker group
sudo usermod -aG docker $USER

# Then log out and log back in, or run:
newgrp docker
```

### Wings Won't Start

If Wings fails to start:

1. Check for errors in the logs:
   ```bash
   sudo journalctl -u wings --no-pager -n 50
   ```

2. Verify that the configuration file is correct:
   ```bash
   sudo cat /etc/phoenixpanel/config.yml
   ```

3. Ensure Docker is running:
   ```bash
   sudo systemctl status docker
   ```

### Network Issues

If you can't connect to Wings from your panel:

1. Check if the Wings API is accessible:
   ```bash
   curl http://localhost:8080/api/system
   ```

2. Verify your firewall configuration:
   ```bash
   sudo ufw status
   ```

3. Make sure the panel URL in the Wings configuration is correct.

### Game Server Won't Start

If game servers won't start:

1. Check Docker disk space:
   ```bash
   df -h /var/lib/docker
   ```

2. Ensure the server has enough free RAM and CPU resources.

3. Check if the required Docker images are accessible:
   ```bash
   docker pull ghcr.io/phoenixpanel/yolks:java_17
   ```

## Next Steps

After successfully installing Wings on your Ubuntu server:

1. Return to your PhoenixPanel admin area
2. Confirm that the node is connected (it should show as "Online")
3. Allocate IP addresses and ports to the node
4. Create your first game server